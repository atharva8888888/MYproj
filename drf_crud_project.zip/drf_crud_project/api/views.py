from django.http import JsonResponse
from .models import Employee
from .serializers import EmployeeSerializer
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

@csrf_exempt
@require_http_methods(["GET", "POST"])
def employee_api(request, id=None):
    try:
        method = request.POST.get('_method', '').upper() if request.method == 'POST' else ''

        # --- GET ---
        if request.method == 'GET':
            if id:
                emp = Employee.objects.get(id=id)
                serializer = EmployeeSerializer(emp)
                return JsonResponse(serializer.data)
            else:
                emp = Employee.objects.all()
                serializer = EmployeeSerializer(emp, many=True)
                return JsonResponse(serializer.data, safe=False)

        # --- DELETE (form override) ---
        elif method == 'DELETE':
            emp = Employee.objects.get(id=id)
            emp.delete()
            return JsonResponse({'msg': 'Employee deleted successfully'})

        # --- PUT (form override) ---
        elif method == 'PUT':
            emp = Employee.objects.get(id=id)
            data = request.POST.dict()
            serializer = EmployeeSerializer(emp, data=data)
            if serializer.is_valid():
                serializer.save()
                return JsonResponse(serializer.data)
            return JsonResponse(serializer.errors, status=400)

        # --- POST (actual add) ---
        elif request.method == 'POST':
            data = request.POST.dict()
            serializer = EmployeeSerializer(data=data)
            if serializer.is_valid():
                serializer.save()
                return JsonResponse(serializer.data)
            return JsonResponse(serializer.errors, status=400)

    except Employee.DoesNotExist:
        return JsonResponse({'error': 'Employee not found'}, status=404)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)
