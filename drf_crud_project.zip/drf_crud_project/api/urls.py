from django.urls import path
from .views import employee_api

urlpatterns = [
    path('employee/', employee_api),
    path('employee/<int:id>/', employee_api),
]
