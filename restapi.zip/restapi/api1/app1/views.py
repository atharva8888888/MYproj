from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from rest_framework.parsers import JSONParser
from .models import Student
from .serializers import PersonSerializer

@csrf_exempt
def stud(request, pk=None):
    if request.method == 'GET':
        if pk:
                stu = Student.objects.get(id=pk)
                ser = PersonSerializer(stu)
                return JsonResponse(ser.data)

        else:
            stu = Student.objects.all()
            ser = PersonSerializer(stu, many=True)
            return JsonResponse(ser.data, safe=False)

@csrf_exempt
def update_student(request, pk):
        if request.method == 'POST':
            try:
                student = Student.objects.get(id=pk)
            except Student.DoesNotExist:
                return JsonResponse({'error': 'Not found'}, status=404)
            data = request.POST
            ser = PersonSerializer(student, data=data)
            if ser.is_valid():
                ser.save()
                return JsonResponse({'msg': 'Updated'})
            return JsonResponse(ser.errors)







    # if request.method == 'POST':
    #     data = JSONParser().parse(request)
    #     serializer = PersonSerializer(data=data)
    #
    #     if serializer.is_valid():
    #         serializer.save()
    #     return JsonResponse(serializer.errors)
    #




#
#
#
# def stud(request, pk):
#         std = Student.objects.get(pk=pk)
#         serialize = studentserializer(std)
#         jsdata = JSONRenderer().render(serialize.data)
#         return HttpResponse(jsdata, content_type="application/json")


