from django.urls import path
from .views import *

urlpatterns = [
    path('stud/', stud),
    path('stud/<int:pk>/', stud),
    path('up/<int:pk>/',update_student)
]
