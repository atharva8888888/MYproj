from django.db import models

# Create your models here.
class productmodel(models.Model):
    prod_name=models.CharField(max_length=100)
    prod_desc=models.TextField()
    prod_quantity=models.IntegerField()
    prod_price=models.FloatField()
    