from django.shortcuts import render
from .forms import productform
from .models import productmodel
# Create your views here.
def show(request):
  
    return render(request,'index.html')

def addprod_view(request):
    if request.method=="POST":
        fm=productform(request.POST)
        if fm.is_valid:
            fm.save()
    
    fm=productform()
    data=productmodel.objects.all()
    return render(request,'addprod.html',{'forms':fm,'data':data})

def deleteview(request,id):
    data1=productmodel.objects.all()
    data=productmodel.objects.filter(id=id)
    data.delete()
    fm=productform()
    return render(request,'addprod.html',{'forms':fm,'data':data1})
def updatedata(request,id):
    if request.method=="POST":
        data=productmodel.objects.get(id=id)
        fm=productform(request.POST,instance=data)
        if fm.is_valid:
            fm.save()
    else:
        data=productmodel.objects.get(id=id)
        fm=productform(instance=data)
    data1=productmodel.objects.all()
    return render(request,'addprod.html',{'forms':fm,'data':data1})