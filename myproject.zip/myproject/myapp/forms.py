from django import forms
from .models import productmodel

class productform(forms.ModelForm):
    class Meta:
        model=productmodel
        fields=["prod_name","prod_desc","prod_quantity","prod_price"]