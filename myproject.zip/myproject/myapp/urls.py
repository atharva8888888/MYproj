 
from django.urls import path
from .import views
urlpatterns = [
    
   path('',views.show,name="home"),
   path('addprod/',views.addprod_view,name='addprod'),
   path('deletedata/<int:id>',views.deleteview,name='deletedata'),
   path('updatedata/<int:id>/',views.updatedata,name="update"),
]
