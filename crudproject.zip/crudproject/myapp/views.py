from django.shortcuts import render, redirect
from .models import *
from .forms import PersonForm

def index(request):
    persons = Person.objects.all()
    form = PersonForm()

    if request.method == 'POST':
        if 'add' in request.POST:
            form = PersonForm(request.POST)
            if form.is_valid():
                form.save()
                return redirect('index')

        elif 'update' in request.POST:
            person = Person.objects.get(id=request.POST['id'])
            form = PersonForm(request.POST, instance=person)
            if form.is_valid():
                form.save()
                return redirect('index')

        elif 'delete' in request.POST:
            person = Person.objects.get(id=request.POST['id'])
            person.delete()
            return redirect('index')

        elif 'edit' in request.POST:
            person = Person.objects.get(id=request.POST['id'])
            form = PersonForm(instance=person)

    return render(request, 'index.html', {'form': form, 'persons': persons})
