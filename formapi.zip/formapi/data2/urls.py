
from django.urls import path
from .views import *
urlpatterns = [
    path('form/', createdata),
    path('f1/',f1)
]
