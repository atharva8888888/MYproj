from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Employee
from .serializers import Empserializer
from django.http import JsonResponse



@csrf_exempt
@api_view(["POST"])
def createdata(request):
    serializer=Empserializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"mess":"data created","data":serializer.data})
    return Response({serializer.errors})
