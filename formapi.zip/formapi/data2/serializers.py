from .models import Employee
from rest_framework import serializers

class Empserializer(serializers.ModelSerializer):
    class Meta:
        model=Employee
        fields=["name","age","salary"]