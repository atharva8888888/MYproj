from django.urls import path
from .views import login, logout, home

urlpatterns = [
    path('', login, name='login'),
    path('home/', home, name='home'),
    path('logout/', logout, name='logout')
]
